#include <cstdlib>
#include <stdint.h>
#include <new>

#include "maxon_malloc.h"
#include "maxon_replacememhandler.h"

MallocPtr g_malloc = malloc;
FreePtr g_free = free;

void SetMemoryHandlingFunctionPointers(MallocPtr mallocFunction, FreePtr freeFunction)
{
	g_malloc = mallocFunction;
	g_free = freeFunction;
};

void ResetMemoryHandlingFunctionPointers()
{
	g_malloc = malloc;
	g_free = free;
};